{{--
    resources/views/user/bookings.blade.php
    Route: GET  /user/bookings                        -> user.bookings
           POST /user/bookings/{booking}/cancel        -> user.bookings.cancel
           POST /user/bookings/{booking}/reschedule    -> user.bookings.reschedule
    Controller: App\Http\Controllers\User\BookingController@index / cancel / reschedule

    Expects from the controller:
      $bookings -> collection/array of
        ['id', 'package', 'date', 'pax', 'status_label', 'status_class']
        status_class is one of: green | amber | rose
--}}
@extends('layouts.user')

@section('title', 'My Bookings')
@section('page-title', 'My Bookings')
@section('page-subtitle', 'Manage your reservations')

@section('content')

    <div class="u-card">
        <h4>My Bookings</h4>
        <p>Manage upcoming &amp; past visits</p>
    </div>

    @forelse ($bookings as $booking)
        <div class="pkg">
            <div>
                <b>{{ $booking['package'] }}</b>
                <span>{{ $booking['date'] }} · {{ $booking['pax'] }} pax</span>
            </div>
            <span class="tag {{ $booking['status_class'] }}">{{ $booking['status_label'] }}</span>
        </div>

        @if ($booking['status_class'] !== 'green')
            <div style="display:flex;gap:8px;margin:-4px 0 12px;">
                <form method="POST" action="{{ route('user.bookings.reschedule', $booking['id']) }}" style="flex:1;">
                    @csrf
                    <button type="submit" class="u-btn ghost" style="padding:8px;font-size:11.5px;">Reschedule</button>
                </form>
                <form method="POST" action="{{ route('user.bookings.cancel', $booking['id']) }}" style="flex:1;" onsubmit="return confirm('Cancel this booking?');">
                    @csrf
                    <button type="submit" class="u-btn ghost" style="padding:8px;font-size:11.5px;color:#e24b4a;border-color:#e24b4a;">Cancel</button>
                </form>
            </div>
        @endif
    @empty
        <div class="u-empty">
            <div class="u-empty-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10a2 2 0 0 1 0-4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v1a2 2 0 0 1 0 4v1a2 2 0 0 1 0 4v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1a2 2 0 0 1 0-4z"></path><path d="M10 3v18" stroke-dasharray="2 3"></path></svg>
            </div>
            <h4>No tickets yet</h4>
            <p>Book a day pass or party package to see it here.</p>
        </div>
    @endforelse

    <div class="u-card" style="margin-top:14px;">
        <h4>Need changes?</h4>
        <p>Reschedule, cancel, or request a refund from the booking above, or start a new one below.</p>
    </div>

    <a href="{{ route('user.booking') }}" class="u-btn" style="margin-top:14px;">+ New Booking</a>

@endsection
