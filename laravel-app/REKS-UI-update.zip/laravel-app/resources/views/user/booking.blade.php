{{--
    resources/views/user/booking.blade.php
    Route: GET  /user/booking  ->  user.booking
           POST /user/booking  ->  user.booking.store
    Controller: App\Http\Controllers\User\BookingController@create / store

    Expects from the controller:
      $dates    -> collection/array of ['value' => 'Y-m-d', 'day' => 'Fri', 'num' => 3]
      $packages -> array keyed by package code, each ['name','desc','price']
--}}
@extends('layouts.user')

@section('title', 'Booking')
@section('page-title', 'Booking')
@section('page-subtitle', 'Pick a date and package')

@section('content')

    <form method="POST" action="{{ route('user.booking.store') }}">
        @csrf

        <div class="u-card">
            <h4>Select a date</h4>
            <p>Available slots this week</p>
        </div>

        <div class="date-strip" id="dateStrip">
            @foreach ($dates as $date)
                <label class="date-chip {{ $loop->first ? 'sel' : '' }}" data-date-chip>
                    <input
                        type="radio"
                        name="visit_date"
                        value="{{ $date['value'] }}"
                        {{ $loop->first ? 'checked' : '' }}
                        style="display:none;"
                    >
                    <span class="dc-day">{{ $date['day'] }}</span>
                    <span class="dc-num">{{ $date['num'] }}</span>
                </label>
            @endforeach
        </div>

        <div class="u-card">
            <h4>Choose package</h4>
            <p>Party inclusions &amp; headcount</p>
        </div>

        @foreach ($packages as $code => $package)
            <label class="pkg" style="cursor:pointer;">
                <div>
                    <b>{{ $package['name'] }}</b>
                    <span>{{ $package['desc'] }}</span>
                </div>
                <div class="price" style="display:flex;align-items:center;gap:6px;">
                    <input type="radio" name="package" value="{{ $code }}" {{ $loop->first ? 'checked' : '' }}>
                    {{ $package['price'] }}
                </div>
            </label>
        @endforeach

        <input
            type="number"
            name="guests"
            min="1"
            class="u-input"
            placeholder="Number of guests (party size)"
            value="{{ old('guests') }}"
            required
        >

        <button type="submit" class="u-btn">Review Booking</button>
    </form>

    <button type="button" class="u-btn ghost" style="margin-top:8px;" onclick="document.getElementById('chatWindow').classList.add('open')">
        💬 Ask AI / Talk to Admin
    </button>

@endsection

@push('scripts')
<script>
    // Keeps the ".sel" visual style in sync with the selected radio button,
    // since the date chips are now real form inputs instead of JS-only tabs.
    document.querySelectorAll('#dateStrip [data-date-chip]').forEach(function (chip) {
        chip.addEventListener('click', function () {
            document.querySelectorAll('#dateStrip [data-date-chip]').forEach(function (c) {
                c.classList.remove('sel');
            });
            chip.classList.add('sel');
        });
    });
</script>
@endpush
