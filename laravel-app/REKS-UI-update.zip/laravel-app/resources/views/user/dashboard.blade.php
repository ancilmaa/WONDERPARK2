{{--
    resources/views/user/dashboard.blade.php
    Route: GET /user/account  ->  user.account
    Controller: App\Http\Controllers\User\DashboardController@index
--}}
@extends('layouts.user')

@section('title', 'Account')
@section('page-title', 'Account')
@section('page-subtitle', 'Manage your REKS account')

@section('content')

    <div class="u-grid-2">
        <div class="u-card u-card-account">
            <div class="u-avatar">{{ strtoupper(substr($user->name ?? 'G', 0, 1)) }}</div>
            <div>
                <h4>Hello, {{ $user->name ?? 'Guest' }} 👋</h4>
                <p>This is your customer account. Use the Waiver, Booking, and My Bookings tabs to sign your waiver, reserve a slot, and manage your visits.</p>
            </div>
        </div>
        <div class="u-card">
            <h4>Email</h4>
            <p>{{ $user->email ?? 'guest@example.com' }}</p>
        </div>
    </div>

    {{--
        Adjust the route name below to match your project's actual logout
        route (e.g. Breeze/Jetstream usually expose "logout").
    --}}
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="u-btn ghost">Logout</button>
    </form>

@endsection
