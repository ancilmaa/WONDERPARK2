<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Account') · REKS Amusement</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('css/user-app-theme.css') }}">
    @stack('styles')
</head>
<body>

<div id="userView">
    <div class="app-frame">

        @include('partials.bottomnav')

        <div class="app-main">
            <div class="phone-status">
                <span>{{ now()->format('g:i A') }}</span>
                <span>REKS Amusement</span>
            </div>

            <div class="phone-head">
                <h2>@yield('page-title', 'Account')</h2>
                <p>@yield('page-subtitle', 'Manage your REKS account')</p>
            </div>

            <div class="ticket-seam" aria-hidden="true"><span></span><span></span></div>

            <div class="app-body">

                @if (session('success'))
                    <div class="u-alert success">{{ session('success') }}</div>
                @endif

                @if (session('error'))
                    <div class="u-alert error">{{ session('error') }}</div>
                @endif

                @if ($errors->any())
                    <div class="u-alert error">{{ $errors->first() }}</div>
                @endif

                @yield('content')

            </div>
        </div>
    </div>
</div>

@include('partials.chat-widget')

@stack('scripts')
</body>
</html>
