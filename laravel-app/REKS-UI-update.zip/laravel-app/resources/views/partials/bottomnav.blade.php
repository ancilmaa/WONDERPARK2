{{--
    resources/views/partials/bottomnav.blade.php

    Renders as a bottom tab bar on mobile and a left sidebar on desktop
    (behavior is handled purely by CSS media queries in user-app-theme.css).

    Active tab is determined by the current route name, so no JS is
    needed to switch pages anymore — each tab is a real Laravel route.
--}}
<nav class="bottomnav">
    <div class="nav-brand" aria-hidden="true">
        <span class="nav-brand-mark">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10a2 2 0 0 1 0-4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v1a2 2 0 0 1 0 4v1a2 2 0 0 1 0 4v1a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-1a2 2 0 0 1 0-4z"></path><path d="M10 3v18" stroke-dasharray="2 3"></path></svg>
        </span>
        <span class="nav-brand-text">REKS<em>Amusement Park</em></span>
    </div>

    <a href="{{ route('user.dashboard') }}"
       class="bn-item {{ request()->routeIs('user.account') ? 'active' : '' }}"
       style="--item-color:#171126;--item-color-soft:#efe9e0;">
        <span class="ic3">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c0-4 4-7 8-7s8 3 8 7"></path></svg>
        </span>
        Account
    </a>

    <a href="{{ route('user.waiver') }}"
       class="bn-item {{ request()->routeIs('user.waiver*') ? 'active' : '' }}"
       style="--item-color:#f5a623;--item-color-soft:#fdf1de;">
        <span class="ic3">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"></path><path d="M14 3v5h5"></path><path d="M9 13h6"></path><path d="M9 17h4"></path></svg>
        </span>
        Waiver
    </a>

    <a href="{{ route('user.booking') }}"
       class="bn-item {{ request()->routeIs('user.booking*') ? 'active' : '' }}"
       style="--item-color:#3b82f6;--item-color-soft:#e8f0fe;">
        <span class="ic3">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="16" rx="2"></rect><path d="M16 3v4"></path><path d="M8 3v4"></path><path d="M3 11h18"></path></svg>
        </span>
        Booking
    </a>

    <a href="{{ route('user.bookings') }}"
       class="bn-item {{ request()->routeIs('user.bookings*') ? 'active' : '' }}"
       style="--item-color:#ef4360;--item-color-soft:#fdeaee;">
        <span class="ic3">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path><path d="M2 13h20"></path></svg>
        </span>
        My Bookings
    </a>
</nav>
